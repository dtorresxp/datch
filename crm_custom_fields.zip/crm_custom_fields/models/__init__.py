# -*- coding: utf-8 -*-

from . import ir_model
from . import ir_model_fields
from . import res_partner
from . import crm_lead
from . import sale_config_settings