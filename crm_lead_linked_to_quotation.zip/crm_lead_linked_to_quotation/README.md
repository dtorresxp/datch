# Quotations from and to CRM Leads

This modules adds a possible linkage between CRM Leads and Quotations.

On Leads, it is possible to list linked quotations and create new ones related.

On quotations, it is possible to link the document to a specific Lead for the same customer.

This module has been developed by Valentin THIRION @ AbAKUS it-solutions.
