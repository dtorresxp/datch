# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).

from . import crm_lead_line
from . import crm_lead
